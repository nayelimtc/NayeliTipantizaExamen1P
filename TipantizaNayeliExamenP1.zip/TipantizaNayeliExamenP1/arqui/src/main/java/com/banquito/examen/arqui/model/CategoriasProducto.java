package com.banquito.examen.arqui.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Categorias_Producto")
public class CategoriasProducto {

    @Id
    @Column(name = "id_categoria", nullable = false)
    private Integer idCategoria;

    @Column(name = "nombre_categoria", length = 100, unique = true, nullable = false)
    private String nombreCategoria;

    @Column(name = "descripcion", length = 255, nullable = true)
    private String descripcion;

    public CategoriasProducto() {
    }

    public CategoriasProducto(Integer idCategoria) {
        this.idCategoria = idCategoria;
    }

    public String getNombreCategoria() {
        return nombreCategoria;
    }

    public void setNombreCategoria(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((idCategoria == null) ? 0 : idCategoria.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CategoriasProducto other = (CategoriasProducto) obj;
        if (idCategoria == null) {
            if (other.idCategoria != null)
                return false;
        } else if (!idCategoria.equals(other.idCategoria))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "CategoriasProducto [idCategoria=" + idCategoria + ", nombreCategoria=" + nombreCategoria
                + ", descripcion=" + descripcion + "]";
    }

}