package com.banquito.examen.arqui.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.banquito.examen.arqui.model.Productos;

public interface ProductoRepository extends JpaRepository<Productos, Integer> {

}