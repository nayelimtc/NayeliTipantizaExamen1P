package com.banquito.examen.arqui.controller;

import com.banquito.examen.arqui.model.CategoriasProducto;
import com.banquito.examen.arqui.service.CategoriaProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/categorias-producto")
public class CategoriaProductoController {

    @Autowired
    private CategoriaProductoService categoriaProductoService;

    @PostMapping
    public ResponseEntity<CategoriasProducto> crearCategoriaProducto(@RequestBody CategoriasProducto categoriaProducto) {
        categoriaProductoService.crearCategoriaProducto(categoriaProducto);
        return ResponseEntity.ok(categoriaProducto);
    }

    @GetMapping
    public ResponseEntity<List<CategoriasProducto>> listarCategoriasProducto() {
        List<CategoriasProducto> categorias = categoriaProductoService.listarCategoriasProducto();
        return ResponseEntity.ok(categorias);
    }

    @GetMapping("/{id}")
    public ResponseEntity<CategoriasProducto> obtenerCategoriaProductoPorId(@PathVariable Integer id) {
        CategoriasProducto categoria = categoriaProductoService.obtenerCategoriaProductoPorId(id);
        return ResponseEntity.ok(categoria);
    }

    @PutMapping("/{id}")
    public ResponseEntity<CategoriasProducto> modificarCategoriaProducto(
            @PathVariable Integer id,
            @RequestBody CategoriasProducto categoriaProducto) {
        categoriaProductoService.modificarCategoriaProducto(id, categoriaProducto);
        return ResponseEntity.ok(categoriaProducto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarCategoriaProducto(@PathVariable Integer id) {
        categoriaProductoService.eliminarCategoriaProducto(id);
        return ResponseEntity.noContent().build();
    }
}
