package com.banquito.examen.arqui.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.banquito.examen.arqui.repository.ProductoRepository;
import com.banquito.examen.arqui.model.Productos;
import com.banquito.examen.arqui.exception.*;
import java.util.List;
import java.util.Optional;
import java.math.BigDecimal;
import java.math.RoundingMode;

@Service
public class ProductoService {

    private final ProductoRepository productoRepository;

    public ProductoService(ProductoRepository productoRepository) {
        this.productoRepository = productoRepository;
    }

    public Productos obtenerProductoPorId(Integer id) {
        Optional<Productos> productoOptional = productoRepository.findById(id);
        if (productoOptional.isPresent()) {
            return productoOptional.get();
        } else {
            throw new ProductoNoEncontradoException("Productos", 
                "No se encontró el producto con ID: " + id);
        }
    }

    public List<Productos> obtenerTodosLosProductos() {
        return productoRepository.findAll();
    }

    @Transactional
    public Productos crearProducto(Productos producto) {
        try {
            return productoRepository.save(producto);
        } catch (Exception e) {
            throw new CrearEntidadException("Productos", 
                "Error al crear el producto. Error: " + e.getMessage());
        }
    }

    @Transactional
    public Productos cambiarEstadoProducto(Integer id, String nuevoEstado) {
        try {
            Optional<Productos> productoOptional = productoRepository.findById(id);
            if (productoOptional.isPresent()) {
                Productos producto = productoOptional.get();
                producto.setEstadoProducto(nuevoEstado);
                return productoRepository.save(producto);
            } else {
                throw new ProductoNoEncontradoException("Productos", 
                    "No se encontró el producto con ID: " + id);
            }
        } catch (Exception e) {
            throw new ActualizarEntidadException("Productos", 
                "Error al cambiar el estado del producto. Error: " + e.getMessage());
        }
    }

    @Transactional
    public Productos aumentarStock(Integer id, Integer cantidadIncrementar, BigDecimal precioCompra) {
        try {
            Optional<Productos> productoOptional = productoRepository.findById(id);
            if (productoOptional.isPresent()) {
                Productos producto = productoOptional.get();
                
                // Calcular nuevo precio de venta (precio de compra + 25%)
                BigDecimal porcentajeIncremento = new BigDecimal("1.25");
                BigDecimal nuevoPrecioVenta = precioCompra.multiply(porcentajeIncremento)
                                                         .setScale(2, RoundingMode.HALF_UP);
                
                // Actualizar stock y precios
                producto.setStockActual(producto.getStockActual() + cantidadIncrementar);
                producto.setCostoCompra(precioCompra);
                producto.setPrecioVenta(nuevoPrecioVenta);
                producto.setEstadoProducto("ACTIVO");
                
                return productoRepository.save(producto);
            } else {
                throw new ProductoNoEncontradoException("Productos", 
                    "No se encontró el producto con ID: " + id);
            }
        } catch (Exception e) {
            throw new ActualizarEntidadException("Productos", 
                "Error al aumentar el stock del producto. Error: " + e.getMessage());
        }
    }

    @Transactional
    public Productos disminuirStock(Integer id, Integer cantidadDisminuir) {
        try {
            Optional<Productos> productoOptional = productoRepository.findById(id);
            if (productoOptional.isPresent()) {
                Productos producto = productoOptional.get();
                
                // Verificar si hay suficiente stock
                if (producto.getStockActual() < cantidadDisminuir) {
                    throw new RuntimeException("No hay suficiente stock disponible");
                }
                
                // Actualizar stock
                producto.setStockActual(producto.getStockActual() - cantidadDisminuir);
                
                return productoRepository.save(producto);
            } else {
                throw new ProductoNoEncontradoException("Productos", 
                    "No se encontró el producto con ID: " + id);
            }
        } catch (Exception e) {
            throw new ActualizarEntidadException("Productos", 
                "Error al disminuir el stock del producto. Error: " + e.getMessage());
        }
    }
}
