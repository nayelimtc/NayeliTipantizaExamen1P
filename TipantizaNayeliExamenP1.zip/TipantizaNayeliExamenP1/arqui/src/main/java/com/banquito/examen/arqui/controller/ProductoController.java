package com.banquito.examen.arqui.controller;

public class ProductoController {

}
