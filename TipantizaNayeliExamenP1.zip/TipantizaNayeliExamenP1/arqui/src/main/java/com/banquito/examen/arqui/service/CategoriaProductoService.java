package com.banquito.examen.arqui.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.banquito.examen.arqui.repository.CategoriaProductoRepository;
import com.banquito.examen.arqui.model.CategoriasProducto;
import com.banquito.examen.arqui.exception.*;
import java.util.List;
import java.util.Optional;

@Service
public class CategoriaProductoService {

    private final CategoriaProductoRepository categoriaProductoRepository;

    public CategoriaProductoService(CategoriaProductoRepository categoriaProductoRepository) {
        this.categoriaProductoRepository = categoriaProductoRepository;
    }

    public List<CategoriasProducto> listarCategoriasProducto() {
        return categoriaProductoRepository.findAll();
    }

    public CategoriasProducto obtenerCategoriaProductoPorId(Integer id) {
        Optional<CategoriasProducto> categoriaOptional = categoriaProductoRepository.findById(id);
        if (categoriaOptional.isPresent()) {
            return categoriaOptional.get();
        } else {
            throw new CategoriaProductoNoEncontradaException("CategoriaProducto", 
                "No se encontró la categoría de producto con ID: " + id);
        }
    }

    @Transactional
    public void crearCategoriaProducto(CategoriasProducto categoriaProducto) {
        try {
            categoriaProductoRepository.save(categoriaProducto);
        } catch (Exception e) {
            throw new CrearEntidadException("CategoriaProducto", 
                "Error al crear la categoría de producto. Error: " + e.getMessage());
        }
    }

    @Transactional
    public void modificarCategoriaProducto(Integer id, CategoriasProducto categoriaProducto) {
        try {
            Optional<CategoriasProducto> categoriaOptional = categoriaProductoRepository.findById(id);
            if (categoriaOptional.isPresent()) {
                CategoriasProducto categoriaDB = categoriaOptional.get();
                // Actualizar los campos necesarios
                categoriaDB.setNombreCategoria(categoriaProducto.getNombreCategoria());
                categoriaDB.setDescripcion(categoriaProducto.getDescripcion());
                categoriaProductoRepository.save(categoriaDB);
            } else {
                throw new CategoriaProductoNoEncontradaException("CategoriaProducto", 
                    "No se encontró la categoría de producto con ID: " + id);
            }
        } catch (Exception e) {
            throw new ActualizarEntidadException("CategoriaProducto", 
                "Error al actualizar la categoría de producto. Error: " + e.getMessage());
        }
    }

    @Transactional
    public void eliminarCategoriaProducto(Integer id) {
        try {
            Optional<CategoriasProducto> categoriaOptional = categoriaProductoRepository.findById(id);
            if (categoriaOptional.isPresent()) {
                categoriaProductoRepository.delete(categoriaOptional.get());
            } else {
                throw new CategoriaProductoNoEncontradaException("CategoriaProducto", 
                    "No se encontró la categoría de producto con ID: " + id);
            }
        } catch (Exception e) {
            throw new EliminarEntidadException("CategoriaProducto", 
                "Error al eliminar la categoría de producto. Error: " + e.getMessage());
        }
    }
}