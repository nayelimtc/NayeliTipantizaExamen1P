package com.banquito.examen.arqui.exception;

public class EliminarEntidadException extends RuntimeException {

    private final Integer errorCode;
    private final String entidad;

    public EliminarEntidadException(String entidad, String message) {
        super(message);
        this.errorCode = 5;
        this.entidad = entidad;
    }

    public EliminarEntidadException(String message) {
        super(message);
        this.errorCode = 5;
        this.entidad = "Entidad";
    }

    @Override
    public String getMessage() {
        return "Error code: " + this.errorCode + ", Entidad: " + this.entidad + ", Mensaje: " + super.getMessage();
    }

    public Integer getErrorCode() {
        return errorCode;
    }

    public String getEntidad() {
        return entidad;
    }
} 