package com.banquito.examen.arqui.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.banquito.examen.arqui.model.CategoriasProducto;

public interface CategoriaProductoRepository extends JpaRepository<CategoriasProducto, Integer> {

}