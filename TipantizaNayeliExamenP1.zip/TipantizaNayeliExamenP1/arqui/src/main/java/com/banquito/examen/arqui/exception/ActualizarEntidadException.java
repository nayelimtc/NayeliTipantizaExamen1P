package com.banquito.examen.arqui.exception;

public class ActualizarEntidadException extends RuntimeException {

    private final Integer errorCode;
    private final String entidad;

    public ActualizarEntidadException(String entidad, String message) {
        super(message);
        this.errorCode = 4;
        this.entidad = entidad;
    }

    public ActualizarEntidadException(String message) {
        super(message);
        this.errorCode = 4;
        this.entidad = "Entidad";
    }

    @Override
    public String getMessage() {
        return "Error code: " + this.errorCode + ", Entidad: " + this.entidad + ", Mensaje: " + super.getMessage();
    }

    public Integer getErrorCode() {
        return errorCode;
    }

    public String getEntidad() {
        return entidad;
    }
} 