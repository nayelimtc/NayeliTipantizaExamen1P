package com.banquito.examen.arqui.exception;

public class ProductoNoEncontradoException extends RuntimeException {

    private final Integer errorCode;
    private final String entidad;

    public ProductoNoEncontradoException(String entidad, String message) {
        super(message);
        this.errorCode = 2;
        this.entidad = entidad;
    }

    public ProductoNoEncontradoException(String message) {
        super(message);
        this.errorCode = 2;
        this.entidad = "Productos";
    }

    @Override
    public String getMessage() {
        return "Error code: " + this.errorCode + ", Entidad: " + this.entidad + ", Mensaje: " + super.getMessage();
    }

    public Integer getErrorCode() {
        return errorCode;
    }

    public String getEntidad() {
        return entidad;
    }
} 