package com.banquito.examen.arqui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArquiApplicationTests {

	@Test
	void contextLoads() {
	}

}
